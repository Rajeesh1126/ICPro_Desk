/**
 * Pure helpers for Timesheet Logs: filter → API params, display/export
 * strings and the per-approver aggregation. No React; unit-testable.
 */
import { formatDateRange } from "../../../utils/dateRange";
import type {
  ApproverLogRow,
  ApproverWeekDetail,
  ReviewerLogApprover,
  ReviewerLogsResponse,
  ReviewerLogWeek,
  TimesheetLogWeek,
} from "./logTypes";

export const currentYear = new Date().getFullYear();
export const weekOptions = Array.from({ length: 52 }, (_, index) => index + 1);

export const createWeekRange = (fromWeek: string, toWeek: string) => {
  if (!fromWeek || !toWeek) {
    return "";
  }

  const from = Number(fromWeek);
  const to = Number(toWeek);

  if (!Number.isInteger(from) || !Number.isInteger(to)) {
    return "";
  }

  const start = Math.min(from, to);
  const end = Math.max(from, to);

  return Array.from(
    { length: end - start + 1 },
    (_item, index) => end - index,
  ).join(",");
};

export const formatWeekRange = (week: { week_start: string; week_end: string }) =>
  formatDateRange(week.week_start, week.week_end);

export const formatSubmittedWeekValue = (week?: TimesheetLogWeek) => {
  if (!week) {
    return "Not Submitted";
  }

  const hours = `${week.total_hours.toFixed(2)} hrs`;
  return `${week.submission_timing} | ${week.timesheet_status} | ${hours}`;
};

export const formatSubmittedWeekExportValue = (week?: TimesheetLogWeek) =>
  formatSubmittedWeekValue(week).split("|")[0].trim();

export const formatApproverDetails = (approvers: ReviewerLogApprover[]) => {
  if (approvers.length === 0) {
    return "";
  }

  return approvers
    .map(
      (approver) =>
        `${approver.approver_name}: ${approver.status} ` +
        `(Accepted ${approver.accepted_count}, Rejected ${approver.rejected_count}, Pending ${approver.pending_count})`,
    )
    .join("; ");
};

export const formatReviewerWeekValue = (week?: ReviewerLogWeek) => {
  if (!week) {
    return "N/A";
  }

  return `${week.review_status} | ${week.completed_approvers}/${week.total_approvers} approvers actioned`;
};

export const formatApproverWeekValue = (week?: ApproverWeekDetail) => {
  if (!week) {
    return "N/A";
  }

  return `${week.submitted_count} submitters | Accepted ${week.accepted_count} | Rejected ${week.rejected_count} | Pending ${week.pending_count}`;
};

export type LogFilters = {
  employee: string;
  year: string;
  fromWeek: string;
  toWeek: string;
};

export const emptyLogFilters: LogFilters = { employee: "", year: "", fromWeek: "", toWeek: "" };

/** Query params for the log endpoints. A week range implies a year (default: this year). */
export function buildLogRequestParams(filters: LogFilters) {
  const params: Record<string, string> = {};
  if (filters.employee) params.employee_id = filters.employee;
  if (filters.year) params.year = filters.year;
  const weeks = createWeekRange(filters.fromWeek, filters.toWeek);
  if (weeks) {
    params.weeks = weeks;
    params.year = filters.year || String(currentYear);
  }
  return params;
}

/** Selectable years: this year and the five before it. */
export const yearOptions = Array.from({ length: 6 }, (_, index) => currentYear - index);

/** Pivot the per-employee approval log into one row per approver, sorted by name. */
export function buildApproverRows(reviewerLogs: ReviewerLogsResponse): ApproverLogRow[] {
  const approvers = new Map<string, ApproverLogRow>();

  reviewerLogs.results.forEach((employee) => {
    reviewerLogs.week_columns.forEach((weekColumn) => {
      const week = employee.weeks[weekColumn.key];
      if (!week?.submitted) {
        return;
      }

      week.approvers.forEach((approver) => {
        const approverKey = `${approver.approver_id ?? "unknown"}-${approver.approver_name}`;
        const approverRow =
          approvers.get(approverKey) ??
          {
            approver_key: approverKey,
            approver_id: approver.approver_id,
            approver_name: approver.approver_name,
            total_submitters: 0,
            weeks: {},
          };

        const approverWeek =
          approverRow.weeks[weekColumn.key] ??
          {
            weeknumber: week.weeknumber,
            weekyear: week.weekyear,
            week_start: week.week_start,
            week_end: week.week_end,
            submitted_count: 0,
            accepted_count: 0,
            rejected_count: 0,
            pending_count: 0,
            submitters: [],
          };

        approverWeek.submitted_count += 1;
        approverWeek.accepted_count += approver.accepted_count;
        approverWeek.rejected_count += approver.rejected_count;
        approverWeek.pending_count += approver.pending_count;
        approverWeek.submitters.push({
          employee_id: employee.employee_id,
          employee_name: employee.employee_name,
          reporting_to: employee.reporting_to,
          status: approver.status,
          accepted_count: approver.accepted_count,
          rejected_count: approver.rejected_count,
          pending_count: approver.pending_count,
        });

        approverRow.weeks[weekColumn.key] = approverWeek;
        approverRow.total_submitters += 1;
        approvers.set(approverKey, approverRow);
      });
    });
  });

  return Array.from(approvers.values()).sort((first, second) =>
    first.approver_name.localeCompare(second.approver_name),
  );
}
