/**
 * Excel exports for the three Timesheet Logs tabs. Each takes the data on
 * screen, writes a workbook and returns the file name. The spreadsheet
 * library is loaded only when an export actually runs.
 */
import { loadXlsx } from "../../../utils/useExportStatus";
import {
  formatApproverDetails,
  formatApproverWeekValue,
  formatReviewerWeekValue,
  formatSubmittedWeekExportValue,
  formatWeekRange,
} from "./logData";
import type {
  ApproverLogRow,
  ReviewerLogsResponse,
  TimesheetLogsResponse,
  TimesheetLogWeekColumn,
} from "./logTypes";

type Cell = string | number;

const today = () => new Date().toISOString().split("T")[0];

const weekHeader = (column: TimesheetLogWeekColumn) =>
  `${column.label} (${formatWeekRange(column)})`;

async function writeSheet(
  rows: Record<string, Cell>[],
  columnWidths: number[],
  sheetName: string,
  fileName: string,
) {
  const XLSX = await loadXlsx();
  const worksheet = XLSX.utils.json_to_sheet(rows);
  worksheet["!cols"] = columnWidths.map((wch) => ({ wch }));
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  XLSX.writeFile(workbook, fileName);
  return fileName;
}

export function exportSubmittedLogs(logs: TimesheetLogsResponse) {
  const rows = logs.results.map((row, index) => {
    const exportRow: Record<string, Cell> = {
      "#": index + 1,
      Employee: row.employee_name,
      "Reporting To": row.reporting_to,
    };
    logs.week_columns.forEach((column) => {
      exportRow[weekHeader(column)] = formatSubmittedWeekExportValue(row.weeks[column.key]);
    });
    return exportRow;
  });

  return writeSheet(
    rows,
    [8, 26, 26, ...logs.week_columns.map(() => 34)],
    "Submitted Logs",
    `Timesheet_Submitted_Logs_${today()}.xlsx`,
  );
}

export function exportApprovalLogs(reviewerLogs: ReviewerLogsResponse) {
  const rows = reviewerLogs.results.map((row, index) => {
    const exportRow: Record<string, Cell> = {
      "#": index + 1,
      Employee: row.employee_name,
      "Reporting To": row.reporting_to,
    };
    reviewerLogs.week_columns.forEach((column) => {
      const week = row.weeks[column.key];
      const header = weekHeader(column);
      exportRow[`${header} Review Status`] = formatReviewerWeekValue(week);
      exportRow[`${header} Pending Approvers`] = week?.pending_approvers ?? 0;
      exportRow[`${header} Approver Details`] = week ? formatApproverDetails(week.approvers) : "";
    });
    return exportRow;
  });

  return writeSheet(
    rows,
    [8, 26, 26, ...reviewerLogs.week_columns.flatMap(() => [34, 18, 70])],
    "Approval Logs",
    `Timesheet_Approval_Logs_${today()}.xlsx`,
  );
}

export function exportApproverLogs(
  approverRows: ApproverLogRow[],
  weekColumns: TimesheetLogWeekColumn[],
) {
  const rows = approverRows.map((row, index) => {
    const exportRow: Record<string, Cell> = {
      "#": index + 1,
      Approver: row.approver_name,
      "Submitted Employees": row.total_submitters,
    };
    weekColumns.forEach((column) => {
      const week = row.weeks[column.key];
      const header = weekHeader(column);
      exportRow[`${header} Summary`] = formatApproverWeekValue(week);
      exportRow[`${header} Submitter Details`] = week
        ? week.submitters
            .map(
              (submitter) =>
                `${submitter.employee_name}: ${submitter.status} ` +
                `(Accepted ${submitter.accepted_count}, Rejected ${submitter.rejected_count}, Pending ${submitter.pending_count})`,
            )
            .join("; ")
        : "";
    });
    return exportRow;
  });

  return writeSheet(
    rows,
    [8, 26, 20, ...weekColumns.flatMap(() => [34, 70])],
    "Approver Logs",
    `Timesheet_Approver_Logs_${today()}.xlsx`,
  );
}
