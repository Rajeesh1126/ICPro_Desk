/** Shapes returned by the timesheet week-log endpoints. */

export type TimesheetLogWeekColumn = {
  key: string;
  weeknumber: number;
  weekyear: number;
  label: string;
  week_start: string;
  week_end: string;
};

export type TimesheetLogWeek = {
  weeknumber: number;
  weekyear: number;
  week_start: string;
  week_end: string;
  timesheet_status: string;
  submission_status: boolean;
  submission_timing: "OnTime" | "Delayed" | "Not Submitted" | "Not Applicable";
  submitted_at: string | null;
  total_hours: number;
  comments: string | null;
};

export type ReviewerLogApprover = {
  approver_id: number | null;
  approver_name: string;
  accepted_count: number;
  rejected_count: number;
  pending_count: number;
  status: "Accepted" | "Rejected" | "Mixed" | "Pending";
};

export type ReviewerLogWeek = {
  weeknumber: number;
  weekyear: number;
  week_start: string;
  week_end: string;
  review_status: "N/A" | "No Action" | "Partially Approved" | "Delayed" | "OnTime" | "Rejected";
  review_summary: string;
  submitted: boolean;
  total_approvers: number;
  completed_approvers: number;
  pending_approvers: number;
  approvers: ReviewerLogApprover[];
};

export type TimesheetLogRow = {
  employee_id: number;
  employee_name: string;
  reporting_to: string;
  weeks: Record<string, TimesheetLogWeek>;
};

export type TimesheetLogsResponse = {
  week_columns: TimesheetLogWeekColumn[];
  results: TimesheetLogRow[];
};

export type ReviewerLogRow = {
  employee_id: number;
  employee_name: string;
  reporting_to: string;
  weeks: Record<string, ReviewerLogWeek>;
};

export type ReviewerLogsResponse = {
  week_columns: TimesheetLogWeekColumn[];
  results: ReviewerLogRow[];
};

export type ApproverSubmitterDetail = {
  employee_id: number;
  employee_name: string;
  reporting_to: string;
  status: ReviewerLogApprover["status"];
  accepted_count: number;
  rejected_count: number;
  pending_count: number;
};

export type ApproverWeekDetail = {
  weeknumber: number;
  weekyear: number;
  week_start: string;
  week_end: string;
  submitted_count: number;
  accepted_count: number;
  rejected_count: number;
  pending_count: number;
  submitters: ApproverSubmitterDetail[];
};

export type ApproverLogRow = {
  approver_key: string;
  approver_id: number | null;
  approver_name: string;
  total_submitters: number;
  weeks: Record<string, ApproverWeekDetail>;
};
