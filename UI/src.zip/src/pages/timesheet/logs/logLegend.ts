/**
 * What each Timesheet Logs status means: icon, colour, label and description.
 * The status key and the table icons both read from here, so they can never
 * drift apart.
 */
import CheckCircleOutlinedIcon from "@mui/icons-material/CheckCircleOutlined";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import HourglassTopOutlinedIcon from "@mui/icons-material/HourglassTopOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import PendingActionsOutlinedIcon from "@mui/icons-material/PendingActionsOutlined";
import RateReviewOutlinedIcon from "@mui/icons-material/RateReviewOutlined";
import TaskAltOutlinedIcon from "@mui/icons-material/TaskAltOutlined";
import type { StatusLegendItem } from "../../../components/timesheet/StatusLegend";
import type { ApproverWeekDetail, ReviewerLogWeek, TimesheetLogWeek } from "./logTypes";

export const timingColor = {
  OnTime: "success.main",
  Delayed: "warning.main",
  "Not Submitted": "error.main",
  "Not Applicable": "text.disabled",
} satisfies Record<TimesheetLogWeek["submission_timing"], string>;

export const reviewColor = {
  OnTime: "success.main",
  Rejected: "error.main",
  "Partially Approved": "warning.main",
  Delayed: "warning.dark",
  "No Action": "info.main",
  "N/A": "text.disabled",
} satisfies Record<ReviewerLogWeek["review_status"], string>;

type LegendMeta = Omit<StatusLegendItem, "count">;

/** Submitted Log: when each employee's week was submitted. */
export const submissionLegend: Record<TimesheetLogWeek["submission_timing"], LegendMeta> = {
  OnTime: {
    key: "OnTime",
    icon: CheckCircleOutlinedIcon,
    color: timingColor.OnTime,
    label: "On time",
    description: "Timesheet submitted on or before the weekly deadline.",
  },
  Delayed: {
    key: "Delayed",
    icon: HourglassTopOutlinedIcon,
    color: timingColor.Delayed,
    label: "Late",
    description: "Timesheet submitted after the weekly deadline.",
  },
  "Not Submitted": {
    key: "Not Submitted",
    icon: CancelOutlinedIcon,
    color: timingColor["Not Submitted"],
    label: "Not submitted",
    description: "No timesheet has been submitted for this week yet.",
  },
  "Not Applicable": {
    key: "Not Applicable",
    icon: HelpOutlineOutlinedIcon,
    color: timingColor["Not Applicable"],
    label: "Not applicable",
    description: "No submission is expected from this employee for this week.",
  },
};

/** Approval Logs: how an employee's submitted week moved through approval. */
export const reviewerLegend: Record<ReviewerLogWeek["review_status"], LegendMeta> = {
  OnTime: {
    key: "OnTime",
    icon: CheckCircleOutlinedIcon,
    color: reviewColor.OnTime,
    label: "Approved on time",
    description: "Every approver accepted the week within the approval window.",
  },
  "Partially Approved": {
    key: "Partially Approved",
    icon: RateReviewOutlinedIcon,
    color: reviewColor["Partially Approved"],
    label: "Partly approved",
    description: "Some approvers have accepted; others have not acted yet.",
  },
  Delayed: {
    key: "Delayed",
    icon: HourglassTopOutlinedIcon,
    color: reviewColor.Delayed,
    label: "Approval late",
    description: "Approvers acted after the approval window had passed.",
  },
  Rejected: {
    key: "Rejected",
    icon: CancelOutlinedIcon,
    color: reviewColor.Rejected,
    label: "Rejected",
    description: "At least one approver rejected entries in this week.",
  },
  "No Action": {
    key: "No Action",
    icon: PendingActionsOutlinedIcon,
    color: reviewColor["No Action"],
    label: "Awaiting approval",
    description: "Submitted, but no approver has acted on it yet.",
  },
  "N/A": {
    key: "N/A",
    icon: HelpOutlineOutlinedIcon,
    color: reviewColor["N/A"],
    label: "Not submitted",
    description: "Nothing was submitted for review this week.",
  },
};

/** Approver Logs: an approver's queue for one week. */
export type ApproverState = "accepted" | "pending" | "rejected" | "none";

export const approverState = (week?: ApproverWeekDetail): ApproverState =>
  !week || week.submitted_count === 0
    ? "none"
    : week.rejected_count > 0
      ? "rejected"
      : week.pending_count > 0
        ? "pending"
        : "accepted";

export const approverLegend: Record<ApproverState, LegendMeta> = {
  accepted: {
    key: "accepted",
    icon: TaskAltOutlinedIcon,
    color: reviewColor.OnTime,
    label: "All accepted",
    description: "This approver accepted every submission they received this week.",
  },
  pending: {
    key: "pending",
    icon: PendingActionsOutlinedIcon,
    color: reviewColor["No Action"],
    label: "Pending",
    description: "Some submissions are still waiting for this approver.",
  },
  rejected: {
    key: "rejected",
    icon: CancelOutlinedIcon,
    color: reviewColor.Rejected,
    label: "Has rejections",
    description: "This approver rejected entries from at least one submitter.",
  },
  none: {
    key: "none",
    icon: RateReviewOutlinedIcon,
    color: reviewColor["N/A"],
    label: "No submissions",
    description: "Nobody submitted a timesheet to this approver this week.",
  },
};

/** Legend items in display order, with how many cells currently show each status. */
export function withCounts<K extends string>(
  legend: Record<K, LegendMeta>,
  statuses: K[],
): StatusLegendItem[] {
  const counts = new Map<string, number>();
  statuses.forEach((status) => counts.set(status, (counts.get(status) ?? 0) + 1));
  return (Object.values(legend) as LegendMeta[]).map((item) => ({
    ...item,
    count: counts.get(item.key) ?? 0,
  }));
}
