import { Badge, Box, Tooltip } from "@mui/material";
import {
  approverLegend,
  approverState,
  reviewColor,
  reviewerLegend,
  submissionLegend,
  timingColor,
} from "./logLegend";
import { formatApproverWeekValue } from "./logData";
import type { ApproverWeekDetail, ReviewerLogWeek, TimesheetLogWeek } from "./logTypes";

/* Week cells in the three log tables. Icon and wording come from logLegend. */

export function TimingIcon({ week }: { week?: TimesheetLogWeek }) {
  const timing = week?.submission_timing ?? "Not Submitted";
  const { icon: Icon, label } = submissionLegend[timing];

  return (
    <Tooltip
      title={`${label}${week ? ` · ${week.total_hours.toFixed(2)} hrs` : ""}`}
    >
      <Box
        component="span"
        sx={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          width: 32,
          height: 32,
        }}
      >
        <Icon sx={{ color: timingColor[timing], fontSize: 22 }} />
      </Box>
    </Tooltip>
  );
}

export function ReviewerIcon({
  week,
  onOpen,
}: {
  week?: ReviewerLogWeek;
  onOpen: () => void;
}) {
  const status = week?.review_status ?? "N/A";
  const { icon: Icon, label } = reviewerLegend[status];
  const canOpen = Boolean(week?.submitted && week.approvers.length > 0);

  return (
    <Tooltip
      title={
        week
          ? `${label} · ${week.completed_approvers}/${week.total_approvers} approvers acted${canOpen ? " · select for details" : ""}`
          : label
      }
    >
      <Box
        component="button"
        type="button"
        onClick={canOpen ? onOpen : undefined}
        sx={{
          width: 32,
          height: 32,
          p: 0,
          border: 0,
          bgcolor: "transparent",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: canOpen ? "pointer" : "default",
        }}
      >
        <Icon sx={{ color: reviewColor[status], fontSize: 22 }} />
      </Box>
    </Tooltip>
  );
}

export function ApproverWeekIcon({
  week,
  onOpen,
}: {
  week?: ApproverWeekDetail;
  onOpen: () => void;
}) {
  const canOpen = Boolean(week?.submitters.length);
  const state = approverState(week);
  const { icon: Icon, color, label } = approverLegend[state];

  return (
    <Tooltip
      title={`${label}${week ? ` · ${formatApproverWeekValue(week)}` : ""}${canOpen ? " · select for details" : ""}`}
    >
      <Box
        component="button"
        type="button"
        onClick={canOpen ? onOpen : undefined}
        sx={{
          width: 32,
          height: 32,
          p: 0,
          border: 0,
          bgcolor: "transparent",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: canOpen ? "pointer" : "default",
        }}
      >
        <Badge
          badgeContent={week?.submitted_count ?? 0}
          color={state === "rejected" ? "error" : state === "pending" ? "warning" : "success"}
          max={99}
          invisible={!canOpen}
        >
          <Icon sx={{ color, fontSize: 22 }} />
        </Badge>
      </Box>
    </Tooltip>
  );
}
