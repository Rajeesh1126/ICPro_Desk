import { FormControl, InputLabel, MenuItem, Select, Stack } from "@mui/material";
import type { ReportingEmployees } from "../../../types/dataTypes";
import { weekOptions, yearOptions, type LogFilters } from "./logData";

interface LogFiltersFormProps {
  filters: LogFilters;
  employees: ReportingEmployees[];
  onChange: (next: LogFilters) => void;
}

/** Fields of the Timesheet Logs filter dialog: employee, year and week range. */
export default function LogFiltersForm({ filters, employees, onChange }: LogFiltersFormProps) {
  const set = (key: keyof LogFilters) => (value: string) => onChange({ ...filters, [key]: value });
  const weekMenu = { PaperProps: { sx: { maxHeight: 250 } } };

  return (
    <Stack spacing={2}>
      <FormControl size="small" fullWidth>
        <InputLabel>Employee</InputLabel>
        <Select label="Employee" value={filters.employee} onChange={(event) => set("employee")(event.target.value)}>
          <MenuItem value="">All</MenuItem>
          {employees.map((employee) => (
            <MenuItem key={employee.id} value={String(employee.id)}>
              {employee.first_name || `User ${employee.id}`}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <FormControl size="small" fullWidth>
        <InputLabel>Year</InputLabel>
        <Select label="Year" value={filters.year} onChange={(event) => set("year")(event.target.value)}>
          <MenuItem value="">Last 4 weeks</MenuItem>
          {yearOptions.map((year) => (
            <MenuItem key={year} value={String(year)}>
              {year}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <FormControl size="small" fullWidth>
        <InputLabel>From Week</InputLabel>
        <Select
          label="From Week"
          value={filters.fromWeek}
          onChange={(event) => set("fromWeek")(event.target.value)}
          MenuProps={weekMenu}
        >
          <MenuItem value="">Any</MenuItem>
          {weekOptions.map((week) => (
            <MenuItem key={week} value={String(week)}>
              W-{week}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <FormControl size="small" fullWidth>
        <InputLabel>To Week</InputLabel>
        <Select
          label="To Week"
          value={filters.toWeek}
          onChange={(event) => set("toWeek")(event.target.value)}
          MenuProps={weekMenu}
        >
          <MenuItem value="">Any</MenuItem>
          {weekOptions.map((week) => (
            <MenuItem key={week} value={String(week)}>
              W-{week}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Stack>
  );
}
