import DateRange from "../../../components/common/DateRange";
import LogDetailDialog, { LogDetailItem } from "../../../components/timesheet/LogDetailDialog";
import type { ApproverWeekDetail, ReviewerLogWeek } from "./logTypes";

export type ReviewerCell = { employeeName: string; week: ReviewerLogWeek };
export type ApproverCell = { approverName: string; week: ApproverWeekDetail };

/** Approval Logs: who approved one employee's week. */
export function ReviewerWeekDialog({ cell, onClose }: { cell: ReviewerCell | null; onClose: () => void }) {
  return (
    <LogDetailDialog
      open={Boolean(cell)}
      onClose={onClose}
      title={cell?.employeeName}
      subtitle={
        cell ? (
          <>
            Week {cell.week.weeknumber} <DateRange start={cell.week.week_start} end={cell.week.week_end} />{" "}
            · {cell.week.completed_approvers}/{cell.week.total_approvers} approvers actioned
          </>
        ) : undefined
      }
    >
      {cell?.week.approvers.map((approver) => (
        <LogDetailItem
          key={`${approver.approver_id}-${approver.approver_name}`}
          name={approver.approver_name}
          details={[
            `Accepted ${approver.accepted_count} | Rejected ${approver.rejected_count} | Pending ${approver.pending_count}`,
          ]}
          status={approver.status}
        />
      ))}
    </LogDetailDialog>
  );
}

/** Approver Logs: everyone who submitted to one approver that week. */
export function ApproverWeekDialog({ cell, onClose }: { cell: ApproverCell | null; onClose: () => void }) {
  return (
    <LogDetailDialog
      open={Boolean(cell)}
      onClose={onClose}
      title={cell?.approverName}
      subtitle={
        cell ? (
          <>
            Week {cell.week.weeknumber} <DateRange start={cell.week.week_start} end={cell.week.week_end} />{" "}
            · {cell.week.submitted_count} submitted employees
          </>
        ) : undefined
      }
    >
      {cell?.week.submitters.map((submitter) => (
        <LogDetailItem
          key={`${submitter.employee_id}-${submitter.employee_name}`}
          name={submitter.employee_name}
          details={[
            `Reporting To: ${submitter.reporting_to || "N/A"}`,
            `Accepted ${submitter.accepted_count} | Rejected ${submitter.rejected_count} | Pending ${submitter.pending_count}`,
          ]}
          status={submitter.status}
        />
      ))}
    </LogDetailDialog>
  );
}
