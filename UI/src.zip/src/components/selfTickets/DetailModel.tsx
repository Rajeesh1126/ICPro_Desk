import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  IconButton,
  Box,
  Grid,
  Chip,
  Stack,
  Paper,
  TextField,
} from "@mui/material";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";
import TaskAltOutlinedIcon from "@mui/icons-material/TaskAltOutlined";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import ChatBubbleOutlineOutlinedIcon from "@mui/icons-material/ChatBubbleOutlineOutlined";

import SendOutlinedIcon from "@mui/icons-material/SendOutlined";

import AssignmentOutlinedIcon from "@mui/icons-material/AssignmentOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import PendingActionsOutlinedIcon from "@mui/icons-material/PendingActionsOutlined";
import EventRepeatOutlinedIcon from "@mui/icons-material/EventRepeatOutlined";

import api from "../../api/axios";
import { useState } from "react";
import { alpha, useTheme } from "@mui/material/styles";
import type { SelfTicketData, SelfTicketLog } from "../../types/dataTypes";
import Avatar from "@mui/material/Avatar";
import ConfirmDialog from "../common/ConfirmDialog";
import {
  compactFieldSx,
  detailLabelSx,
  detailValueSx,
  formSectionSx,
  getModalPalette,
  getPriorityPalette,
  modalFormIconSx,
  doListDetailOwnerAvatarSx,
  doListDetailOwnerRowSx,
  doListDetailTabButtonSx,
  selfTicketsDetailModelDialogActionsSx,
  selfTicketsDetailModelDialogContentSx,
  selfTicketsDetailModelDialogPaperSx,
  selfTicketsDetailModelCommentPaperSx,
  selfTicketsDetailModelCommentTitleSx,
  selfTicketsDetailModelCommentWrapperSx,
  selfTicketsDetailModelFooterButtonsSx,
  selfTicketsDetailModelFooterStackSx,
  doListDetailFieldSx,
  doListDetailPriorityChipSx,
  doListDetailCommentListSx,
  doListDetailStatusPanelSx,
  doListDetailFieldLabelSx,
  doListDetailFieldValueSx,
  doListDetailCloseButtonSx,
  selfTicketsDetailModelNoteBoxSx,
  doListDetailEyebrowSx,
  doListDetailNumberSx,
  doListDetailOwnerLabelSx,
  doListCommentAuthorSx,
  ticketDetailActivitySectionSx,
  ticketDetailSummaryBannerSx,
  ticketDetailDescriptionSx,
  ticketDetailSummaryLabelSx,
  detailSubjectSx,
  detailDescriptionTextSx,
} from "../../styles/common";
import { formatDateTime } from "../common/formatDate";
import { showNotification } from "../../api/notificationService";

export default function TicketDetailModal({
  open,
  onClose,
  data,
}: {
  open: boolean;
  onClose: () => void;
  data: SelfTicketData;
}) {
  const [closeModelOpen, setCloseModelOpen] = useState(false);
  const [cancelModelOpen, setCancelModelOpen] = useState(false);
  const [openCommentsModal, setOpenCommentsModal] = useState(false);
  const [openProgressModal, setOpenProgressModal] = useState(false);
  const [openTargetRevisionModal, setOpenTargetRevisionModal] = useState(false);
  const [comments, setcomments] = useState("");
  const [task, setTask] = useState(data);
  const theme = useTheme();
  const isDark = theme.palette.mode === "dark";
  const modalPalette = getModalPalette(theme);

  const pStyle = getPriorityPalette(theme, data.priority);

  const currentUserParsed = Number(localStorage.getItem("user") || "null");
  const userId = currentUserParsed ?? null;

  const statusMessages: Record<string, string> = {
    closed: "Do List task closed successfully.",
    cancelled: "Do List task cancelled successfully.",
    "date revision": "Target date revision request sent successfully.",
  };

  const handleConfirm = async (
    status?: string,
    payload?: { comments?: string },
  ): Promise<boolean> => {
    try {
      const requestBody: {
        current_status?: string;
        comments?: string;
      } = {};

      if (status) {
        requestBody.current_status = status;
      }

      if (payload?.comments) {
        requestBody.comments = payload.comments;
      }
      const response = await api.patch<SelfTicketData>(
        `/self-tickets/${task.id}/?do_List=true`,
        requestBody,
      );

      showNotification({
        type: "success",
        message:
          statusMessages[status ?? ""] ??
          "Do List task marked as In Progress successfully.",
      });

      setTask(response.data);
      setcomments("");
      if (closeModelOpen || cancelModelOpen) {
        onClose();
      }

      return true;
    } catch {
      return false;
    }
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={onClose}
        fullWidth
        maxWidth="lg"
        slotProps={{
          paper: {
            sx: selfTicketsDetailModelDialogPaperSx,
          },
        }}
      >
        <DialogTitle component="div">
          <Stack
            direction="row"
            spacing={1.25}
            alignItems="center"
            justifyContent="space-between"
          >
            <Stack
              direction="row"
              spacing={1.25}
              alignItems="center"
              minWidth={0}
            >
              <Box sx={modalFormIconSx}>
                <AssignmentOutlinedIcon fontSize="small" />
              </Box>
              <Box>
                <Typography sx={doListDetailEyebrowSx}>
                  Self task
                </Typography>
                <Typography
                  variant="h6"
                  fontWeight={900}
                  sx={doListDetailNumberSx}
                >
                  {task.number}
                </Typography>
                <Chip
                  label={`${task.priority?.toUpperCase()} PRIORITY`}
                  sx={doListDetailPriorityChipSx({ pStyle })}
                />
              </Box>
            </Stack>

            <Box sx={doListDetailOwnerRowSx}>
              {task.creator !== userId ? (
                <Stack
                  direction="row"
                  spacing={1}
                  alignItems="center"
                  sx={doListDetailStatusPanelSx({
                    alpha,
                    isDark,
                    theme,
                  })}
                >
                  <Avatar sx={doListDetailOwnerAvatarSx}>
                    {task.creator_name
                      ? task.creator_name.charAt(0).toUpperCase()
                      : "U"}
                  </Avatar>
                  <Box>
                    <Typography sx={doListDetailOwnerLabelSx}>
                      Owner
                    </Typography>
                    <Typography sx={detailValueSx}>
                      {task.creator_name || "Unassigned"}
                    </Typography>
                  </Box>
                </Stack>
              ) : (
                ""
              )}
              <IconButton aria-label="Close dialog"
                onClick={onClose}
                sx={doListDetailCloseButtonSx}
              >
                <CloseOutlinedIcon fontSize="small" />
              </IconButton>
            </Box>
          </Stack>
        </DialogTitle>

        <DialogContent sx={selfTicketsDetailModelDialogContentSx}>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: task.logs?.length > 0 ? 8 : 12 }}>
              <Paper variant="outlined" sx={formSectionSx}>
                <Box sx={ticketDetailSummaryBannerSx({ theme })}>
                  <Typography
                    sx={ticketDetailSummaryLabelSx({
                      alpha,
                      detailLabelSx,
                      theme,
                    })}
                  >
                    Subject
                  </Typography>
                  <Typography sx={detailSubjectSx}>
                    {task.task}
                  </Typography>
                </Box>
                <Typography sx={detailLabelSx}>Description</Typography>
                <Box
                  sx={ticketDetailDescriptionSx({ modalPalette })}
                >
                  <Typography
                    variant="body2"
                    sx={detailDescriptionTextSx}
                  >
                    {data.description}
                  </Typography>
                </Box>

                <Grid container spacing={1.25}>
                  {[
                    {
                      label: "Estimated hours",
                      value:
                        task.est_hours != null
                          ? `${task.est_hours} hrs`
                          : "N/A",
                    },
                    {
                      label: "Target date",
                      value: task.target_date
                        ? task.target_date.split("-").reverse().join("-")
                        : "N/A",
                    },
                    {
                      label: "Task type",
                      value: task.type || "Unassigned",
                      capitalize: true,
                    },
                    {
                      label: "Related ticket",
                      value: task.ticket_number || "Not linked",
                    },
                    {
                      label: "Reminder interval",
                      value: task.reminder_interval
                        ? `${task.reminder_interval} ${task.reminder_interval === 1 ? "day" : "days"}`
                        : "Not set",
                    },
                    {
                      label: "Current status",
                      value: task.current_status || "Open",
                      capitalize: true,
                    },
                  ].map(({ label, value, capitalize }) => (
                    <Grid key={label} size={{ xs: 6, sm: 6, md: 4 }}>
                      <Box
                        sx={doListDetailFieldSx({
                          alpha,
                          isDark,
                          theme,
                        })}
                      >
                        <Typography
                          sx={doListDetailFieldLabelSx(
                            { detailLabelSx },
                          )}
                        >
                          {label}
                        </Typography>
                        <Typography
                          sx={doListDetailFieldValueSx(
                            { capitalize, detailValueSx },
                          )}
                        >
                          {value}
                        </Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </Paper>
            </Grid>
            {/* RIGHT SIDE (Timeline) */}
            {task.logs?.length ? (
              <Grid size={{ xs: 12, md: 4 }}>
                <Paper
                  variant="outlined"
                  sx={ticketDetailActivitySectionSx({ formSectionSx })}
                >
                  <Typography
                    variant="h6"
                    gutterBottom
                    sx={selfTicketsDetailModelCommentTitleSx}
                  >
                    Status / Comments
                  </Typography>

                  <Box
                    sx={doListDetailCommentListSx({
                      alpha,
                      isDark,
                      theme,
                    })}
                  >
                    {task.logs?.map((log: SelfTicketLog) => (
                      <Box
                        key={log.id}
                        sx={selfTicketsDetailModelCommentWrapperSx({
                          isCurrentUser: log.creator === userId,
                        })}
                      >
                        <Typography
                          variant="caption"
                          sx={doListCommentAuthorSx}
                        >
                          {log.creator_name || "User"}
                          <Box component="span" sx={{ mx: 0.75 }}>
                            {formatDateTime(log.created_at)}
                          </Box>
                        </Typography>
                        <Paper
                          elevation={0}
                          sx={selfTicketsDetailModelCommentPaperSx({
                            alpha,
                            isDark,
                            theme,
                            isCurrentUser: log.creator === userId,
                          })}
                        >
                          <Typography variant="body2" color="text.primary">
                            {log.comments || "No comments"}
                          </Typography>
                        </Paper>
                      </Box>
                    ))}
                  </Box>
                </Paper>
              </Grid>
            ) : (
              ""
            )}
          </Grid>
        </DialogContent>

        <DialogActions sx={selfTicketsDetailModelDialogActionsSx}>
          {["open"].includes(task.current_status) &&
            task.creator === userId && (
              <Stack sx={selfTicketsDetailModelFooterStackSx}>
                <Box
                  sx={selfTicketsDetailModelNoteBoxSx({
                    alpha,
                    isDark,
                    theme,
                  })}
                >
                  <InfoOutlinedIcon color="primary" />
                  <Typography variant="caption" color="text.secondary">
                    <strong>Note:</strong> To edit or modify a To-Do List item,
                    switch to <strong>Table (List) View</strong>. Editing is not
                    available in <strong>Card View</strong>.
                  </Typography>
                </Box>
                <Stack
                  direction="row"
                  spacing={1}
                  sx={selfTicketsDetailModelFooterButtonsSx}
                >
                  <Button
                    onClick={() => setOpenProgressModal(true)}
                    variant="contained"
                    color="info"
                    disabled={task.current_status === "closed"}
                    startIcon={<PendingActionsOutlinedIcon />}
                  >
                    <Box
                      component="span"
                      sx={{ display: { xs: "inline", sm: "none" } }}
                    >
                      Update
                    </Box>
                    <Box
                      component="span"
                      sx={{ display: { xs: "none", sm: "inline" } }}
                    >
                      Update Progress
                    </Box>
                  </Button>
                  <Button
                    onClick={() => setCloseModelOpen(true)}
                    variant="contained"
                    color="success"
                    startIcon={<TaskAltOutlinedIcon />}
                  >
                    <Box
                      component="span"
                      sx={{ display: { xs: "inline", sm: "none" } }}
                    >
                      Close
                    </Box>
                    <Box
                      component="span"
                      sx={{ display: { xs: "none", sm: "inline" } }}
                    >
                      Close Task
                    </Box>
                  </Button>
                  <Button
                    onClick={() => setCancelModelOpen(true)}
                    variant="outlined"
                    color="error"
                    startIcon={<CancelOutlinedIcon />}
                  >
                    <Box
                      component="span"
                      sx={{ display: { xs: "inline", sm: "none" } }}
                    >
                      Cancel
                    </Box>
                    <Box
                      component="span"
                      sx={{ display: { xs: "none", sm: "inline" } }}
                    >
                      Cancel Task
                    </Box>
                  </Button>
                </Stack>
              </Stack>
            )}

          {task.creator !== userId && (
            <Stack direction="row" spacing={1}>
              <Button
                onClick={() => setOpenCommentsModal(true)}
                variant="outlined"
                color="warning"
                disabled={task.current_status === "closed"}
                startIcon={<ChatBubbleOutlineOutlinedIcon />}
                sx={doListDetailTabButtonSx}
              >
                Comments
              </Button>
              <Button
                onClick={() => setOpenTargetRevisionModal(true)}
                variant="outlined"
                color="warning"
                disabled={["closed", "cancelled"].includes(task.current_status)}
                startIcon={<EventRepeatOutlinedIcon />}
                sx={doListDetailTabButtonSx}
              >
                Revise Target Date
              </Button>
            </Stack>
          )}
        </DialogActions>
      </Dialog>

      <ConfirmDialog
        open={closeModelOpen}
        onClose={() => setCloseModelOpen(false)}
        onConfirm={async () => {
          if (await handleConfirm("closed", { comments }))
            setCloseModelOpen(false);
        }}
        title="Close Task"
        titleIcon={<TaskAltOutlinedIcon />}
        description="Please provide a reason for closing this task"
        confirmLabel="Confirm"
        confirmColor="success"
        confirmIcon={<TaskAltOutlinedIcon />}
        confirmDisabled={!comments.trim()}
        tone="success"
      >
        <TextField
          autoFocus
          required
          multiline
          rows={4}
          fullWidth
          label="Reason for task closure"
          value={comments}
          onChange={(event) => setcomments(event.target.value)}
          placeholder="e.g., Task completed successfully, Issue resolved, Requirements fulfilled..."
          sx={compactFieldSx}
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={openProgressModal}
        onClose={() => setOpenProgressModal(false)}
        onConfirm={async () => {
          if (await handleConfirm("", { comments }))
            setOpenProgressModal(false);
        }}
        title="Update Progress"
        titleIcon={<TaskAltOutlinedIcon />}
        description="Please provide an update on the current progress of this ticket."
        confirmLabel="Submit"
        confirmColor="info"
        confirmIcon={<SendOutlinedIcon />}
        confirmDisabled={!comments.trim()}
        tone="info"
      >
        <TextField
          autoFocus
          required
          multiline
          rows={4}
          fullWidth
          label="Progress Notes"
          value={comments}
          onChange={(event) => setcomments(event.target.value)}
          placeholder="Describe the current progress, completed work, and any pending tasks..."
          sx={compactFieldSx}
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={cancelModelOpen}
        onClose={() => setCancelModelOpen(false)}
        onConfirm={async () => {
          if (await handleConfirm("cancelled", { comments }))
            setCancelModelOpen(false);
        }}
        title="Cancel Task"
        titleIcon={<CancelOutlinedIcon />}
        description="Please provide a reason for cancelling this task"
        confirmLabel="Confirm"
        confirmColor="error"
        confirmIcon={<CancelOutlinedIcon />}
        confirmDisabled={!comments.trim()}
        tone="error"
      >
        <TextField
          autoFocus
          required
          multiline
          rows={4}
          fullWidth
          label="Reason for task cancellation"
          value={comments}
          onChange={(event) => setcomments(event.target.value)}
          placeholder="e.g., Insufficient information provided, Duplicate task, Out of scope..."
          sx={compactFieldSx}
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={openCommentsModal}
        onClose={() => setOpenCommentsModal(false)}
        onConfirm={async () => {
          if (await handleConfirm("", { comments }))
            setOpenCommentsModal(false);
        }}
        title="Add Comments"
        titleIcon={<ChatBubbleOutlineOutlinedIcon />}
        description="Please provide comments for this task."
        confirmLabel="Submit"
        confirmColor="warning"
        confirmIcon={<SendOutlinedIcon />}
        confirmDisabled={!comments.trim()}
        tone="warning"
      >
        <TextField
          autoFocus
          required
          multiline
          rows={4}
          fullWidth
          label="Give Comments"
          value={comments}
          onChange={(event) => setcomments(event.target.value)}
          placeholder="e.g., Insufficient information provided, Duplicate task, Out of scope..."
          sx={compactFieldSx}
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={openTargetRevisionModal}
        onClose={() => setOpenTargetRevisionModal(false)}
        onConfirm={async () => {
          if (await handleConfirm("date revision", { comments }))
            setOpenTargetRevisionModal(false);
        }}
        title="Request Target Date Revision"
        titleIcon={<EventRepeatOutlinedIcon />}
        description="Please provide the reason for extending or revising the target date."
        confirmLabel="Send Request"
        confirmColor="warning"
        confirmIcon={<SendOutlinedIcon />}
        confirmDisabled={!comments.trim()}
        tone="warning"
      >
        <TextField
          autoFocus
          required
          multiline
          rows={4}
          fullWidth
          label="Reason for target date revision"
          value={comments}
          onChange={(event) => setcomments(event.target.value)}
          placeholder="Explain why the target date needs to be revised or extended..."
          sx={compactFieldSx}
        />
      </ConfirmDialog>
    </>
  );
}
