import { useState, type ReactNode } from "react";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import {
  Avatar,
  Badge,
  Box,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Menu,
  MenuItem,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import FormatListBulletedOutlinedIcon from "@mui/icons-material/FormatListBulletedOutlined";
import TaskAltOutlinedIcon from "@mui/icons-material/TaskAltOutlined";
import LogoutOutlinedIcon from "@mui/icons-material/LogoutOutlined";
import LockResetOutlinedIcon from "@mui/icons-material/LockResetOutlined";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import AdminPanelSettingsOutlinedIcon from "@mui/icons-material/AdminPanelSettingsOutlined";
import BadgeOutlinedIcon from "@mui/icons-material/BadgeOutlined";
import SupervisorAccountOutlinedIcon from "@mui/icons-material/SupervisorAccountOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";
import { alpha, type Theme } from "@mui/material/styles";
import pdfFile from "../../assets/Work_Wise_Process_Flow.pdf";
import logo from "../../assets/icpro_logo.svg";
import api from "../../api/axios";
import { sanitizeUserMessage } from "../../utils/errorUtils";
import { showNotification } from "../../api/notificationService";
import { useThemeMode } from "../../styles/theme/themeModeContext";
import {
  headerAvatarSx,
  notificationEmptyStateSx,
  notificationItemTextSx,
  notificationMenuHeaderSx,
  notificationMenuHeaderIconSx,
  notificationMenuSelfTicketItemSx,
  notificationMenuSelfTicketIconSx,
  notificationMenuTicketItemSx,
  notificationMenuTicketIconSx,
  headerMenuButtonSx,
  headerProfileButtonSx,
  headerProfileChevronSx,
  headerProfileTriggerNameSx,
  headerProfileTriggerTextSx,
  appBarHeaderProfileBodySx,
  appBarHeaderProfileCardSx,
  appBarHeaderProfileDetailRowSx,
  appBarHeaderProfileFooterButtonSx,
  appBarHeaderProfileHeaderSx,
  appBarHeaderProfileInfoIconSx,
  appBarHeaderProfileMetaSx,
  appBarHeaderProfileTextSx,
  appBarHeaderProfileValueSx,
  profileUsernameSx,
  profileTruncatedTextSx,
  dialogContentTop,
  marginTopMediumSx,
  marginTopSmallSx,
  pushRightSx,
} from "../../styles/common";
import type { NotificationsType } from "../../types/dataTypes";
import { ELEVATION } from "../../styles/tokens";
import { clearSession } from "../../api/session";

const emptyNotifications: NotificationsType = {
  selfticketOpenCount: 0,
  ticketOpenCount: 0,
};

const coloredIconButtonSx =
  (color: "primary" | "info" | "warning" | "secondary" | "error" | "muted") =>
  (theme: Theme) => {
    const iconColor =
      color === "muted"
        ? theme.palette.text.secondary
        : theme.palette[color].main;

    return {
      color: iconColor,
      "&:hover": {
        bgcolor: alpha(iconColor, theme.palette.mode === "dark" ? 0.18 : 0.1),
      },
    };
  };

const menuButtonSx = (theme: Theme) => ({
  ...(headerMenuButtonSx as object),
  ...coloredIconButtonSx("primary")(theme),
  alignItems: "center",
  alignSelf: "center",
  height: 40,
  justifyContent: "center",
  p: 0,
  width: 40,
  display: "inline-flex",
  "&:hover": {
    bgcolor: "transparent",
  },
});

const notificationMenuPaperSx = (theme: Theme) => ({
  width: "min(360px, calc(100vw - 24px))",
  mt: 1.25,
  overflow: "hidden",
  borderRadius: 2,
  border: "1px solid",
  borderColor: "divider",
  bgcolor: "background.paper",
  boxShadow: theme.palette.mode === "dark" ? ELEVATION.dark.menu : ELEVATION.light.menu,
});

const profileMenuPaperSx = (theme: Theme) => ({
  width: "min(420px, calc(100vw - 24px))",
  maxHeight: "calc(100dvh - 96px)",
  mt: 2.5,
  overflow: "hidden",
  borderRadius: 2,
  border: "1px solid",
  borderColor: "divider",
  bgcolor: "background.paper",
  boxShadow: theme.palette.mode === "dark" ? ELEVATION.dark.menu : ELEVATION.light.menu,
});

const menuListSx = { p: 0 };

type StoredPermission = {
  id?: number;
  name?: string;
  codename?: string;
};

type StoredRole = {
  id?: number;
  name?: string;
  permissions?: StoredPermission[];
};

type StoredUser = {
  id?: number;
  username?: string;
  first_name?: string;
  last_name?: string;
  full_name?: string;
  email?: string;
  designation?: string;
  reporting_to_first_name?: string;
  reporting_to_last_name?: string;
  is_staff?: boolean;
  role?: string | StoredRole[];
};

function getStoredUser(): StoredUser {
  try {
    const value: unknown = JSON.parse(
      localStorage.getItem("currentUser") ??
        localStorage.getItem("user") ??
        "{}",
    );
    return typeof value === "object" && value !== null
      ? (value as StoredUser)
      : {};
  } catch {
    return {};
  }
}

/** One labelled line in the profile menu (icon, label, value). */
function ProfileDetail({
  icon,
  color = "primary",
  label,
  children,
}: {
  icon: ReactNode;
  color?: "primary" | "secondary" | "info";
  label: string;
  children: ReactNode;
}) {
  return (
    <Box sx={appBarHeaderProfileDetailRowSx}>
      <Box sx={appBarHeaderProfileInfoIconSx({ color })}>{icon}</Box>
      <Typography variant="caption" color="text.secondary" fontWeight={900}>
        {label}
      </Typography>
      <Box sx={appBarHeaderProfileValueSx}>{children}</Box>
    </Box>
  );
}

/** Profile text value with a dash when the corresponding login field is empty. */
function ProfileValue({ value }: { value?: string | null }) {
  return (
    <Typography
      variant="body2"
      fontWeight={600}
      title={value || undefined}
      sx={profileTruncatedTextSx}
      color={value ? "text.primary" : "text.secondary"}
    >
      {value || "Not set"}
    </Typography>
  );
}

type ResponsiveAppBarProps = {
  onMenuClick?: () => void;
};

type ChangePasswordForm = {
  old_password: string;
  new_password: string;
  confirm_password: string;
};

type ChangePasswordErrors = Partial<
  Record<keyof ChangePasswordForm | "non_field_errors" | "detail", string | string[]>
>;

type ChangePasswordErrorResponse = {
  response?: {
    status?: number;
    data?: ChangePasswordErrors;
  };
};

const emptyPasswordForm: ChangePasswordForm = {
  old_password: "",
  new_password: "",
  confirm_password: "",
};

function isChangePasswordErrorResponse(
  error: unknown,
): error is ChangePasswordErrorResponse {
  return typeof error === "object" && error !== null && "response" in error;
}

function formatPasswordError(error?: string | string[]) {
  if (Array.isArray(error)) {
    return sanitizeUserMessage(error.join(" "));
  }

  return error ? sanitizeUserMessage(error) : undefined;
}

export default function ResponsiveAppBar({
  onMenuClick,
}: ResponsiveAppBarProps) {
  const navigate = useNavigate();
  const { mode, toggleMode } = useThemeMode();
  const [notificationAnchor, setNotificationAnchor] =
    useState<HTMLElement | null>(null);
  const [profileAnchor, setProfileAnchor] = useState<HTMLElement | null>(null);
  const [notifications] = useState<NotificationsType>(emptyNotifications);
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [passwordForm, setPasswordForm] =
    useState<ChangePasswordForm>(emptyPasswordForm);
  const [passwordErrors, setPasswordErrors] = useState<ChangePasswordErrors>(
    {},
  );
  const [changingPassword, setChangingPassword] = useState(false);

  const currentUser = getStoredUser();
  const firstName = currentUser.first_name || localStorage.getItem("first_name") || "";
  const lastName = currentUser.last_name || "";
  const loggedUser =
    [firstName, lastName].filter(Boolean).join(" ") ||
    currentUser.full_name ||
    currentUser.username ||
    "";
  const avatarInitials = [firstName, lastName]
    .filter(Boolean)
    .map((name) => name.charAt(0).toUpperCase())
    .join("") || loggedUser.charAt(0).toUpperCase();
  const role =
    localStorage.getItem("role") ||
    (Array.isArray(currentUser.role)
      ? currentUser.role
          .map((item) => item.name)
          .filter(Boolean)
          .join(", ")
      : "");
  const reportingTo = [
    currentUser.reporting_to_first_name,
    currentUser.reporting_to_last_name,
  ].filter(Boolean).join(" ");

  const totalNotifications =
    notifications.selfticketOpenCount + notifications.ticketOpenCount;

  const downloadProcessFlow = () => {
    const link = document.createElement("a");
    link.href = pdfFile;
    link.download = "Work_Wise_Process_Flow.pdf";
    link.click();
  };

  const logout = () => {
    clearSession();
    setProfileAnchor(null);
    navigate("/", { replace: true });
  };

  const openChangePasswordDialog = () => {
    setProfileAnchor(null);
    setPasswordForm(emptyPasswordForm);
    setPasswordErrors({});
    setChangePasswordOpen(true);
  };

  const closeChangePasswordDialog = () => {
    if (changingPassword) return;
    setChangePasswordOpen(false);
    setPasswordForm(emptyPasswordForm);
    setPasswordErrors({});
  };

  const updatePasswordForm = <K extends keyof ChangePasswordForm>(
    key: K,
    value: ChangePasswordForm[K],
  ) => {
    const sanitizedValue = value.replace(/\s/g, "");

    setPasswordForm((current) => ({ ...current, [key]: sanitizedValue }));
    setPasswordErrors((current) => ({ ...current, [key]: undefined }));
  };

  const submitChangePassword = async () => {
    if (
      !passwordForm.old_password ||
      !passwordForm.new_password ||
      !passwordForm.confirm_password
    ) {
      showNotification({
        type: "warning",
        message:
          "Current password, new password and confirmation are required.",
      });
      return;
    }

    if (passwordForm.new_password !== passwordForm.confirm_password) {
      showNotification({
        type: "warning",
        message: "New password and confirm password do not match.",
      });
      return;
    }

    setChangingPassword(true);
    setPasswordErrors({});
    try {
      await api.post("/users/change_password/", passwordForm, {
        suppressGlobalError: true,
      });
      showNotification({
        type: "success",
        message: "Password changed successfully. Please login again.",
      });
      logout();
    } catch (error: unknown) {
      if (isChangePasswordErrorResponse(error) && error.response?.status === 400) {
        const errors = error.response.data ?? {};

        setPasswordErrors(errors);

        const generalError =
          formatPasswordError(errors.non_field_errors) ||
          formatPasswordError(errors.detail);

        if (generalError) {
          showNotification({ type: "error", message: sanitizeUserMessage(generalError) });
        }
      }
    } finally {
      setChangingPassword(false);
    }
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          minHeight: { xs: 58, sm: 64 },
          flexShrink: 0,
          px: { xs: 0.75, sm: 1, lg: 1 },
          gap: { xs: 0.25, sm: 0.75 },
          bgcolor: "background.paper",
        }}
      >
          <IconButton
            aria-label="Open navigation"
            onClick={onMenuClick}
            sx={menuButtonSx}
          >
            <MenuOutlinedIcon />
          </IconButton>

          <Box
            component={RouterLink}
            to="/Home"
            aria-label="ICPro home"
            sx={{
              display: "inline-flex",
              alignItems: "center",
              flexShrink: 0,
            }}
          >
            <Box
              component="img"
              src={logo}
              alt="ICPro"
              sx={{ width: { xs: 64, sm: 84, md: 96 }, height: 32, objectFit: "contain" }}
            />
          </Box>

          <Stack
            direction="row"
            alignItems="center"
            spacing={{ xs: 0, sm: 0.5 }}
            sx={pushRightSx}
          >
            <Tooltip title="Process flow">
              <IconButton
                aria-label="Download process flow"
                onClick={downloadProcessFlow}
                sx={{ ...coloredIconButtonSx("info"), display: { xs: "none", sm: "inline-flex" } }}
              >
                <InfoOutlinedIcon />
              </IconButton>
            </Tooltip>
            <Tooltip
              title={
                mode === "dark" ? "Switch to light mode" : "Switch to dark mode"
              }
            >
              <IconButton
                aria-label={
                  mode === "dark"
                    ? "Switch to light mode"
                    : "Switch to dark mode"
                }
                onClick={toggleMode}
                sx={coloredIconButtonSx(
                  mode === "dark" ? "warning" : "primary",
                )}
              >
                {mode === "dark" ? (
                  <LightModeOutlinedIcon />
                ) : (
                  <DarkModeOutlinedIcon />
                )}
              </IconButton>
            </Tooltip>
            <Tooltip
              title={
                totalNotifications
                  ? `${totalNotifications} action items`
                  : "No notifications"
              }
            >
              <IconButton
                aria-label="Notifications"
                onClick={(event) => setNotificationAnchor(event.currentTarget)}
                sx={{
                  ...coloredIconButtonSx(totalNotifications ? "error" : "muted"),
                  display: { xs: "none", sm: "inline-flex" },
                }}
              >
                {totalNotifications > 0 ? (
                  <Badge badgeContent={totalNotifications} color="error">
                    <NotificationsOutlinedIcon />
                  </Badge>
                ) : (
                  <NotificationsOutlinedIcon />
                )}
              </IconButton>
            </Tooltip>
            <Tooltip title="Account settings">
              <Button
                id="account-menu-button"
                aria-label="Account menu"
                aria-controls={profileAnchor ? "account-menu" : undefined}
                aria-expanded={profileAnchor ? "true" : undefined}
                aria-haspopup="menu"
                onClick={(event) => setProfileAnchor(event.currentTarget)}
                endIcon={<KeyboardArrowDownRoundedIcon sx={headerProfileChevronSx(Boolean(profileAnchor))} />}
                sx={headerProfileButtonSx(Boolean(profileAnchor))}
              >
                <Avatar sx={headerAvatarSx}>
                  {avatarInitials}
                </Avatar>
                <Stack spacing={0.125} sx={headerProfileTriggerTextSx}>
                  <Typography variant="body2" sx={headerProfileTriggerNameSx}>
                    {loggedUser || "Account"}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={profileTruncatedTextSx}>
                    {role || "Account settings"}
                  </Typography>
                </Stack>
              </Button>
            </Tooltip>
          </Stack>
      </Box>

      <Menu
        anchorEl={notificationAnchor}
        open={Boolean(notificationAnchor)}
        onClose={() => setNotificationAnchor(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        slotProps={{
          paper: {
            elevation: 0,
            sx: notificationMenuPaperSx,
          },
          list: { sx: menuListSx },
        }}
      >
        <Box sx={notificationMenuHeaderSx({ alpha })}>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            gap={2}
          >
            <Box minWidth={0}>
              <Typography fontWeight={900} lineHeight={1.15}>
                Notifications
              </Typography>
              <Typography
                variant="body2"
                color="text.secondary"
                sx={marginTopSmallSx}
              >
                {totalNotifications
                  ? `${totalNotifications} action item${totalNotifications === 1 ? "" : "s"} need attention`
                  : "You are all caught up"}
              </Typography>
            </Box>
            <Box sx={notificationMenuHeaderIconSx({ alpha })}>
              {totalNotifications > 0 ? (
                <Badge badgeContent={totalNotifications} color="error">
                  <NotificationsOutlinedIcon fontSize="small" />
                </Badge>
              ) : (
                <NotificationsOutlinedIcon fontSize="small" />
              )}
            </Box>
          </Stack>
        </Box>
        <Divider />
        {totalNotifications === 0 ? (
          <Box sx={notificationEmptyStateSx}>
            <Typography fontWeight={800}>No notifications</Typography>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={marginTopMediumSx}
            >
              New ticket updates will appear here.
            </Typography>
          </Box>
        ) : (
          [
            <MenuItem
              key="self-tickets"
              component={RouterLink}
              to="/Home/SelfTickets"
              onClick={() => setNotificationAnchor(null)}
              sx={notificationMenuSelfTicketItemSx({ alpha })}
            >
              <Box sx={notificationMenuSelfTicketIconSx({ alpha })}>
                <FormatListBulletedOutlinedIcon fontSize="small" />
              </Box>
              <Box minWidth={0} sx={notificationItemTextSx}>
                <Typography fontWeight={900} lineHeight={1.15}>
                  Do List
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Self tickets waiting for action
                </Typography>
              </Box>
              <Badge
                badgeContent={notifications.selfticketOpenCount}
                color="primary"
              />
            </MenuItem>,
            <MenuItem
              key="tickets"
              component={RouterLink}
              to="/Home/Tickets"
              onClick={() => setNotificationAnchor(null)}
              sx={notificationMenuTicketItemSx({ alpha })}
            >
              <Box sx={notificationMenuTicketIconSx({ alpha })}>
                <TaskAltOutlinedIcon fontSize="small" />
              </Box>
              <Box minWidth={0} sx={notificationItemTextSx}>
                <Typography fontWeight={900} lineHeight={1.15}>
                  Tickets
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Assigned ticket updates
                </Typography>
              </Box>
              <Badge
                badgeContent={notifications.ticketOpenCount}
                color="primary"
              />
            </MenuItem>,
          ]
        )}
      </Menu>

      <Menu
        id="account-menu"
        anchorEl={profileAnchor}
        open={Boolean(profileAnchor)}
        onClose={() => setProfileAnchor(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        slotProps={{
          paper: {
            elevation: 0,
            sx: profileMenuPaperSx,
          },
          list: {
            sx: menuListSx,
            "aria-labelledby": "account-menu-button",
          },
        }}
      >
        <Box sx={appBarHeaderProfileBodySx}>
          <Box sx={appBarHeaderProfileCardSx({ alpha })}>
            <Box sx={appBarHeaderProfileHeaderSx}>
              <Avatar sx={headerAvatarSx}>
                {avatarInitials}
              </Avatar>
              <Stack spacing={0.5} sx={appBarHeaderProfileTextSx}>
                <Typography variant="subtitle1" fontWeight={800} sx={profileTruncatedTextSx}>
                  {loggedUser || "Signed in"}
                </Typography>
                {currentUser.username && (
                  <Typography variant="caption" color="text.secondary" sx={profileUsernameSx}>
                    @{currentUser.username}
                  </Typography>
                )}
                {currentUser.email && (
                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={profileTruncatedTextSx}
                  >
                    {currentUser.email}
                  </Typography>
                )}
              </Stack>
            </Box>

            <Stack spacing={1} sx={appBarHeaderProfileMetaSx}>
              <Box sx={appBarHeaderProfileDetailRowSx}>
                <Box
                  sx={appBarHeaderProfileInfoIconSx({
                    color: "primary",
                  })}
                >
                  <AdminPanelSettingsOutlinedIcon fontSize="small" />
                </Box>
                <Typography
                  variant="caption"
                  color="text.secondary"
                  fontWeight={900}
                >
                  Role
                </Typography>
                <Box sx={appBarHeaderProfileValueSx}>
                  <Chip
                    label={role || "No roles assigned"}
                    color="primary"
                    variant="outlined"
                  />
                </Box>
              </Box>

              <ProfileDetail icon={<BadgeOutlinedIcon fontSize="small" />} color="secondary" label="Designation">
                <ProfileValue value={currentUser.designation} />
              </ProfileDetail>

              <ProfileDetail
                icon={<SupervisorAccountOutlinedIcon fontSize="small" />}
                color="secondary"
                label="Reporting To"
              >
                <ProfileValue value={reportingTo} />
              </ProfileDetail>

              <ProfileDetail icon={<EmailOutlinedIcon fontSize="small" />} color="info" label="Email">
                <ProfileValue value={currentUser.email} />
              </ProfileDetail>
            </Stack>

            <Divider />

            <Stack
              direction={{ xs: "column", sm: "row" }}
              spacing={1}
              sx={appBarHeaderProfileMetaSx}
            >
              <Button
                fullWidth
                variant="outlined"
                startIcon={<LockResetOutlinedIcon />}
                onClick={openChangePasswordDialog}
                sx={appBarHeaderProfileFooterButtonSx}
              >
                Change password
              </Button>
              <Button
                fullWidth
                variant="contained"
                color="error"
                startIcon={<LogoutOutlinedIcon />}
                onClick={logout}
                sx={appBarHeaderProfileFooterButtonSx}
              >
                Logout
              </Button>
            </Stack>
          </Box>
        </Box>
      </Menu>

      <Dialog
        open={changePasswordOpen}
        onClose={closeChangePasswordDialog}
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems="center">
            <LockResetOutlinedIcon color="primary" />
            <Typography variant="h6">Change Password</Typography>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={dialogContentTop}>
            <TextField
              label="Current Password"
              type="password"
              value={passwordForm.old_password}
              onChange={(event) =>
                updatePasswordForm("old_password", event.target.value)
              }
              fullWidth
              required
              autoComplete="current-password"
              error={Boolean(passwordErrors.old_password)}
              helperText={formatPasswordError(passwordErrors.old_password)}
            />
            <TextField
              label="New Password"
              type="password"
              value={passwordForm.new_password}
              onChange={(event) =>
                updatePasswordForm("new_password", event.target.value)
              }
              fullWidth
              required
              autoComplete="new-password"
              error={Boolean(passwordErrors.new_password)}
              helperText={formatPasswordError(passwordErrors.new_password)}
            />
            <TextField
              label="Confirm Password"
              type="password"
              value={passwordForm.confirm_password}
              onChange={(event) =>
                updatePasswordForm("confirm_password", event.target.value)
              }
              fullWidth
              required
              autoComplete="new-password"
              error={Boolean(passwordErrors.confirm_password)}
              helperText={formatPasswordError(passwordErrors.confirm_password)}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button
            variant="outlined"
            onClick={closeChangePasswordDialog}
            disabled={changingPassword}
            startIcon={<CancelOutlinedIcon />}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={submitChangePassword}
            disabled={changingPassword}
            startIcon={changingPassword ? undefined : <LockResetOutlinedIcon />}
          >
            {changingPassword ? "Changing..." : "Change"}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
